import {
  type Master,
  type Service,
  type Booking,
  type BotMessage,
  type Settings,
  type PortfolioItem,
  type BotAction,
  insertMasterSchema,
  insertServiceSchema,
  insertBookingSchema,
  botMessageSchema,
  settingsSchema,
  portfolioItemSchema,
} from "@shared/schema";

const BASE_URL = "/api";

async function request<T>(input: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${BASE_URL}${input}`, {
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
    credentials: "same-origin",
    ...init,
  });

  if (!response.ok) {
    const text = await response.text();
    let message = text;
    try {
      const parsed = JSON.parse(text);
      message = parsed.message ?? text;
    } catch {}
    throw new Error(message || `Request failed with status ${response.status}`);
  }
  if (response.status === 204) return undefined as T;
  return (await response.json()) as T;
}

export const api = {
  async uploadFile(file: File) {
    const formData = new FormData();
    formData.append("file", file);
    const response = await fetch(`${BASE_URL}/upload`, { method: "POST", body: formData });
    if (!response.ok) {
      const text = await response.text();
      throw new Error(text || "Ошибка загрузки файла");
    }
    const data = await response.json();
    return (data && data.url) as string;
  },

  // … оставшиеся методы без изменений …

  async getPortfolio(params: { masterId?: string; style?: string; q?: string; page?: number; pageSize?: number } = {}) {
    const query = new URLSearchParams(
      Object.fromEntries(Object.entries(params).filter(([_, v]) => v !== undefined && v !== ""))
    );
    return request<{ portfolio: (PortfolioItem & { mediaType?: string; masterName?: string | null })[]; total: number }>(
      `/portfolio?${query.toString()}`
    );
  },

  async addPortfolioItem(payload: { url: string; title: string; masterId?: string; style?: string; mediaType?: "image" | "video" }) {
    const body = { ...payload };
    return request<{ item: PortfolioItem }>(`/portfolio`, {
      method: "POST",
      body: JSON.stringify(body),
    });
  },

  async deletePortfolioItem(id: string) {
    await request<void>(`/portfolio/${id}`, { method: "DELETE" });
  },
};