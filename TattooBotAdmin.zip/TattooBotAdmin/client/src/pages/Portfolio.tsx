import React from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import PortfolioFilters from "@/components/PortfolioFilters";
import PortfolioDialog from "@/components/PortfolioDialog";
import PortfolioGallery from "@/components/PortfolioGallery";

export default function Portfolio() {
  const qc = useQueryClient();
  const [filters, setFilters] = React.useState<{ masterId?: string; style?: string; q?: string }>(
    {}
  );
  const [page, setPage] = React.useState(1);
  const [open, setOpen] = React.useState(false);

  const { data, isLoading, isError, error } = useQuery({
    queryKey: ["portfolio", filters, page],
    queryFn: () => api.getPortfolio({ ...filters, page, pageSize: 24 }),
  });

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["portfolio"] });
  };

  return (
    <div className="p-4 space-y-4">
      <PortfolioFilters
        value={filters}
        onChange={(v) => {
          setFilters(v);
          setPage(1);
        }}
        onAdd={() => setOpen(true)}
      />

      {isLoading && <div>Загрузка…</div>}
      {isError && <div className="text-red-500">{(error as any)?.message || "Ошибка"}</div>}

      {data && (
        <>
          <PortfolioGallery
            items={data.portfolio}
            onDelete={async (id) => {
              await api.deletePortfolioItem(id);
              refresh();
            }}
          />

          <div className="flex items-center justify-between pt-2">
            <span className="text-xs text-gray-500">
              Показано {data.portfolio.length} из {data.total}
            </span>
            <div className="flex gap-2">
              <button
                className="px-2 py-1 border rounded disabled:opacity-50"
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page <= 1}
              >
                ← Назад
              </button>
              <button
                className="px-2 py-1 border rounded disabled:opacity-50"
                onClick={() => {
                  if (data.portfolio.length >= 24) setPage((p) => p + 1);
                }}
                disabled={data.portfolio.length < 24}
              >
                Далее →
              </button>
            </div>
          </div>
        </>
      )}

      <PortfolioDialog
        open={open}
        onClose={() => setOpen(false)}
        onSaved={refresh}
      />
    </div>
  );
}