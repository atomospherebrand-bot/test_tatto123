import React from "react";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";

type Props = {
  value: { masterId?: string; style?: string; q?: string };
  onChange: (v: Props["value"]) => void;
  onAdd: () => void;
};

export default function PortfolioFilters({ value, onChange, onAdd }: Props) {
  const { data: masters } = useQuery({
    queryKey: ["masters"],
    queryFn: () => api.getMasters(),
  });

  return (
    <div className="flex flex-wrap items-center gap-3 mb-4">
      <select
        className="border rounded px-2 py-1"
        value={value.masterId || ""}
        onChange={(e) => onChange({ ...value, masterId: e.target.value || undefined })}
      >
        <option value="">Все мастера</option>
        {(masters || []).map((m) => (
          <option key={m.id} value={m.id}>
            {m.nickname || m.name}
          </option>
        ))}
      </select>

      <input
        className="border rounded px-2 py-1"
        placeholder="Стиль"
        value={value.style || ""}
        onChange={(e) => onChange({ ...value, style: e.target.value || undefined })}
      />

      <input
        className="border rounded px-2 py-1"
        placeholder="Поиск по названию"
        value={value.q || ""}
        onChange={(e) => onChange({ ...value, q: e.target.value || undefined })}
      />

      <button
        className="ml-auto rounded px-3 py-2 bg-black text-white"
        onClick={onAdd}
      >
        Загрузить работу
      </button>
    </div>
  );
}