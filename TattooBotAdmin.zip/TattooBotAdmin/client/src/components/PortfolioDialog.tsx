import React from "react";
import { api } from "@/lib/api";
import { useQuery } from "@tanstack/react-query";

type Props = {
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
};

export default function PortfolioDialog({ open, onClose, onSaved }: Props) {
  const { data: masters } = useQuery({
    queryKey: ["masters"],
    queryFn: () => api.getMasters(),
  });

  const [title, setTitle] = React.useState("");
  const [style, setStyle] = React.useState("");
  const [masterId, setMasterId] = React.useState<string | undefined>(undefined);
  const [mediaType, setMediaType] = React.useState<"image" | "video">("image");
  const [file, setFile] = React.useState<File | null>(null);
  const [url, setUrl] = React.useState("");

  React.useEffect(() => {
    if (!open) {
      setTitle(""); setStyle(""); setMasterId(undefined); setMediaType("image"); setFile(null); setUrl("");
    }
  }, [open]);

  if (!open) return null;

  const submit = async () => {
    let finalUrl = url.trim();
    if (!finalUrl && file) {
      finalUrl = await api.uploadFile(file);
    }
    if (!finalUrl) return alert("Выбери файл или укажи URL");

    await api.addPortfolioItem({
      url: finalUrl,
      title: title || "Работа",
      style: style || undefined,
      masterId,
      mediaType,
    });
    onSaved();
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-4 w-full max-w-lg">
        <h3 className="text-lg font-semibold mb-3">Добавить работу</h3>

        <div className="space-y-3">
          <div className="flex gap-2">
            <input className="border rounded px-2 py-1 flex-1"
              placeholder="Название"
              value={title}
              onChange={(e)=>setTitle(e.target.value)}
            />
            <select className="border rounded px-2 py-1"
              value={mediaType}
              onChange={(e)=>setMediaType(e.target.value as any)}
            >
              <option value="image">Фото</option>
              <option value="video">Видео</option>
            </select>
          </div>

          <div className="flex gap-2">
            <select className="border rounded px-2 py-1 flex-1"
              value={masterId || ""}
              onChange={(e)=>setMasterId(e.target.value || undefined)}
            >
              <option value="">Без мастера</option>
              {(masters||[]).map(m=>(
                <option key={m.id} value={m.id}>{m.nickname || m.name}</option>
              ))}
            </select>

            <input className="border rounded px-2 py-1 flex-1"
              placeholder="Стиль / теги"
              value={style}
              onChange={(e)=>setStyle(e.target.value)}
            />
          </div>

          <div className="flex gap-2 items-center">
            <input type="file" onChange={(e)=>setFile(e.target.files?.[0]||null)} />
            <span className="text-sm text-gray-500">или</span>
            <input className="border rounded px-2 py-1 flex-1"
              placeholder="URL (http… или /uploads/…)"
              value={url}
              onChange={(e)=>setUrl(e.target.value)}
            />
          </div>
        </div>

        <div className="mt-4 flex justify-end gap-2">
          <button className="px-3 py-2 rounded border" onClick={onClose}>Отмена</button>
          <button className="px-3 py-2 rounded bg-black text-white" onClick={submit}>Сохранить</button>
        </div>
      </div>
    </div>
  );
}