import { Router } from "express";
import { and, desc, eq, ilike, sql } from "drizzle-orm";
import { db } from "../db";
import { portfolioTable, mastersTable } from "@shared/schema";
import { z } from "zod";

const router = Router();

const listSchema = z.object({
  masterId: z.string().uuid().optional(),
  style: z.string().optional(),
  q: z.string().optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(24),
});

const createSchema = z.object({
  url: z.string().min(1),
  title: z.string().min(1),
  masterId: z.string().uuid().optional(),
  style: z.string().optional(),
  mediaType: z.enum(["image","video"]).default("image"),
});

router.get("/", async (req, res, next) => {
  try {
    const { masterId, style, q, page, pageSize } = listSchema.parse(req.query);
    const where = and(
      masterId ? eq(portfolioTable.masterId, masterId) : undefined,
      style ? ilike(portfolioTable.style, `%${style}%`) : undefined,
      q ? ilike(portfolioTable.title, `%${q}%`) : undefined,
    );

    const [{ count }] = await db
      .select({ count: sql<number>`count(*)` })
      .from(portfolioTable)
      .where(where);

    const items = await db
      .select({
        id: portfolioTable.id,
        url: portfolioTable.url,
        title: portfolioTable.title,
        masterId: portfolioTable.masterId,
        style: portfolioTable.style,
        mediaType: portfolioTable.mediaType,
        createdAt: portfolioTable.createdAt,
        masterName: mastersTable.name,
      })
      .from(portfolioTable)
      .leftJoin(mastersTable, eq(mastersTable.id, portfolioTable.masterId))
      .where(where)
      .orderBy(desc(portfolioTable.createdAt))
      .limit(pageSize)
      .offset((page - 1) * pageSize);

    res.json({ portfolio: items, total: Number(count) });
  } catch (err) {
    next(err);
  }
});

router.post("/", async (req, res, next) => {
  try {
    const body = createSchema.parse(req.body);
    const isUpload = typeof body.url === "string" && body.url.startsWith("/uploads/");
    const isHttp = typeof body.url === "string" && (body.url.startsWith("http://") || body.url.startsWith("https://"));
    if (!isUpload && !isHttp) {
      return res.status(400).json({ message: "Invalid url" });
    }

    const [inserted] = await db
      .insert(portfolioTable)
      .values({
        url: body.url,
        title: body.title,
        masterId: body.masterId ?? null,
        style: body.style ?? null,
        mediaType: body.mediaType ?? "image",
      })
      .returning();

    res.status(201).json({ item: inserted });
  } catch (err) {
    next(err);
  }
});

router.delete("/:id", async (req, res, next) => {
  try {
    const id = z.string().uuid().parse(req.params.id);
    await db.delete(portfolioTable).where(eq(portfolioTable.id, id));
    res.status(204).end();
  } catch (err) {
    next(err);
  }
});

export default router;