import { Router } from "express";
import path from "path";
import { upload } from "../middleware/upload";

const router = Router();

/**
 * POST /api/upload
 * multipart/form-data with "file"
 * -> { url: "/uploads/<file>" }
 */
router.post("/upload", upload.single("file"), (req, res) => {
  const file = (req as any).file as Express.Multer.File | undefined;
  if (!file) {
    return res.status(400).json({ message: "Файл не получен (формат multipart/form-data, поле 'file')." });
  }
  const filename = path.basename(file.path);
  // файл раздаётся server/index.ts через app.use("/uploads", express.static(UPLOAD_DIR));
  res.json({ url: `/uploads/${filename}` });
});

export default router;
